window.onload = function () {
    
    let path = 'flights.json';
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if(xhr.readyState == 4 && xhr.status == 200) {
            buildPage(xhr.responseText);
            btnAllFlightHandler();
            
        }
        
    };
    xhr.open('GET',path,true);
    xhr.send();
    
}

let allFlights;

function buildPage(text) {
    allFlights = JSON.parse(text);
        
    // Builds flight table
    let output = '<tr>';
    allFlights.flights.forEach((item,i) => {
        output += `<td>${item.flightNumber}</td>
        <td>${item.dayOfWeek}</td>
        <td>${item.departureTime}</td>
        <td>${item.destination.code} (${item.destination.city}, ${item.destination.country}), region = ${item.destination.region}</td>`;
        output += '<td>';
        //Checks Pilot
        output += item.pilot === undefined ? 
            'not yet assigned' : item.pilot.nickName === undefined ? 
            `${item.pilot.firstName} ${item.pilot.lastName}` : `${item.pilot.firstName} ${item.pilot.lastName} (${item.pilot.nickName})`;
        
        output += '</td><td>';
        //Checks CoPilot
        output += item.copilot === undefined ?
            'not yet assigned' : item.copilot.nickName === undefined ?
            `${item.copilot.firstName} ${item.copilot.lastName}` : `${item.copilot.firstName} ${item.copilot.lastName} (${item.copilot.nickName})`;
        
        output += '</td></tr>';
    });
    let table = document.querySelector('table');
    table.innerHTML += `${output}`;
    
    //alert('Finished reading the file');
}

function btnAllFlightHandler() {
    let allFlifhtsBtn = document.getElementById('btnAllFlights');
    allFlifhtsBtn.addEventListener('click',() => {
        //Display how many flights
        document.getElementById('fQuantity').innerHTML += `Flights (${++allFlights.flights.length})`;
    })
}
